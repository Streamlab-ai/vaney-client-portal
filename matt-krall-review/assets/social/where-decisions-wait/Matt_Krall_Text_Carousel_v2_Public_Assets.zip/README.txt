WHERE DECISIONS WAIT
Matt Krall text carousel v2

14 finished slides, 1080 x 1350 pixels (4:5).

PNG: ready for social upload in slide order 01-14.
PDF: 14 pages, selectable text and embedded Inter font.
SVG: one editable, embedded-font file per slide.
HTML: self-contained offline preview; no external fonts or scripts.
Copy JSON: public slide wording and layout values.

Final call to action: https://mattkrall.com/

SVG text remains text. Applications vary in support for embedded fonts;
Inter Regular is included for editors that require local installation.
This package contains only public-facing creative assets.
