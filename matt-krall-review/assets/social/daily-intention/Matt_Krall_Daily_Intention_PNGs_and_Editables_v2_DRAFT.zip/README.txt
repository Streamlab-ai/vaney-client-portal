MATT KRALL | CAROUSEL REVIEW FILES

Six square cards, 1080 x 1080 px. Numbered PNGs are in order.
The PDF is an ordered review copy. SVG and HTML files are editable sources.
Inter fonts are included for design editing.

The frames and interview excerpts come from Unicorn Talks UT21:
https://www.youtube.com/watch?v=NvmlF23m9fg

Editorial reflections and prompts are labeled separately from Matt’s words.
The cards are marked as review drafts and are not approved for publication.
